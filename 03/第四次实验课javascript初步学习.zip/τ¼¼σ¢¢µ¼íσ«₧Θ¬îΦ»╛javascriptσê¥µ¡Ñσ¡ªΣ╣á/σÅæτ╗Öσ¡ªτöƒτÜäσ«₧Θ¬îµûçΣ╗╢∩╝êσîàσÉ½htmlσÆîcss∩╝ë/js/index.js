$(function () {
   //在这里输入具体的js代码
});
